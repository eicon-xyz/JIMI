# 本组 GPU 环境记录（group2 · 私密）

> **勿提交 Git**（已在 [`.gitignore`](.gitignore) 中忽略）。  
> 可提交 Git 的脱敏版：[`docs/校园gpu使用.template.md`](docs/校园gpu使用.template.md)

---

## 0. 组内文档一览

| 文件 | 读者 | 用途 |
|------|------|------|
| **本文档** `校园gpu使用.md` | 全组 | 凭据、接口、进度、交接表（含密码） |
| [`docs/校园gpu使用.template.md`](docs/校园gpu使用.template.md) | 全组 | 无密码模板，可提交仓库 |
| [`docs/校园GPU-B端联调清单_v2.md`](docs/校园GPU-B端联调清单_v2.md) | **B 端** | Windows 联调操作手册 |
| [`server/docs/A端-GPU容器部署详细指南-group2_v2.md`](server/docs/A端-GPU容器部署详细指南-group2_v2.md) | **A 端** | 容器内部署与运维 |

**发给 A 端同学时附带**：

1. `server/docs/A端-GPU容器部署详细指南-group2_v2.md`（仓库内路径，或导出 PDF）
2. 本文档 `校园gpu使用.md`（**私发**，含 SSH/Jupyter 密码）

---

## 1. 平台接入（group2 @ 10.246.2.7）

| 项 | 值 |
|----|-----|
| 小组 | group2 |
| 宿主机 IP | `10.246.2.7` |
| JupyterLab | `http://10.246.2.7:28888/lab` |
| Jupyter Token | `group2-jupyter-123` |
| VS Code Server | `http://10.246.2.7:28080` |
| VS Code 密码 | `group2-code-123` |
| SSH | `ssh student@10.246.2.7 -p 12202` |
| SSH 密码 | `group2-ssh-123` |
| 用户名 | `student`（固定） |

**端口规律（其他小组参考）**：group2 → Jupyter `28888`、VS Code `28080`、SSH `12202`。详见 [`docs/校园GPU与OmniParser环境速查_v2.md`](docs/校园GPU与OmniParser环境速查_v2.md) §1.3。

---

## 2. HAJIMI 接口（已部署 · 2026-07-01）

| 项 | 值 |
|----|-----|
| 网络方案 | **B — SSH 隧道**（B 端 Windows 建立，A 端无需额外映射） |
| **A 端 Base URL**（B 系统设置） | `http://127.0.0.1:8010` |
| Demo Key | `hajimi-demo-2026` |
| health 状态 | **正常**（`detector_device=cuda`，`omniparser_ready=true`） |
| 容器内 OmniParser | `http://127.0.0.1:8002`（仅 A 端自检，B 不直连） |
| 容器内 A FastAPI | `http://127.0.0.1:8010`（经隧道映射到 B 本机同端口） |

### 2.1 B 端隧道命令（每次联调前）

```powershell
ssh -L 8010:127.0.0.1:8010 student@10.246.2.7 -p 12202
```

保持该窗口**不要关闭**；密码见上表「SSH 密码」。

或使用脚本（会短暂建隧道并写入 B 端设置）：

```powershell
cd E:\University\greed3-2\Shixun\HAJIMI_UI
python scripts/b_group2_intranet_setup.py
```

### 2.2 HTTP 接口（Base = `http://127.0.0.1:8010`，须隧道已建立）

| 用途 | 方法 | 完整 URL | 认证 |
|------|------|----------|------|
| 健康检查 | GET | `http://127.0.0.1:8010/api/demo/health` | 无 |
| 任务处理 | POST | `http://127.0.0.1:8010/api/demo/process` | Header `X-Demo-Key` |
| 屏幕检验 | POST | `http://127.0.0.1:8010/api/demo/inspect` | Header `X-Demo-Key` |
| 重新定位 | POST | `http://127.0.0.1:8010/api/demo/relocate` | Header `X-Demo-Key` |

**期望 health JSON（关键字段）**：

```json
{
  "status": "ok",
  "detector_backend": "auto",
  "detector_device": "cuda",
  "omniparser_ready": true
}
```

契约：[`api-contract-demo_v2.yaml`](api-contract-demo_v2.yaml)

---

## 3. 容器内路径与服务

| 路径 / 服务 | 说明 |
|-------------|------|
| `/workspace/code/HAJIMI_UI` | B 端仓库同步的 A FastAPI 代码 |
| `/workspace/code/OmniParser` | OmniParser 源码 + weights 软链接 |
| `/workspace/code/omniparser_api/.venv` | OmniParser Python 环境 |
| `/workspace/code/HAJIMI_UI/server/.venv` | A 端 server 环境 |
| `/workspace/models` | HF 模型权重 |
| `/workspace/code/HAJIMI_UI/logs/omniparser.log` | OmniParser 日志 |
| `/workspace/code/HAJIMI_UI/logs/a_end.log` | A 端日志 |

**容器内启停**（SSH 登录后）：

```bash
bash /workspace/code/HAJIMI_UI/scripts/gpu_group2_container_services.sh status
bash /workspace/code/HAJIMI_UI/scripts/gpu_group2_container_services.sh start-all
```

**B 端远程运维脚本**（在本机 Windows 项目根目录）：

| 脚本 | 用途 |
|------|------|
| `python scripts/gpu_group2_remote.py phase0` | 验证 GPU / workspace |
| `python scripts/gpu_group2_remote.py services` | 查看远程 health |
| `python scripts/gpu_group2_deploy.py --all` | 上传 HAJIMI + 安装 + 启服务 |
| `python scripts/b_group2_intranet_setup.py` | 隧道 + 写 `user_settings.json` |
| `python scripts/b_group2_e2e_verify.py` | 隧道 + `verify_integration` |

---

## 4. 部署进度

### A 端（容器内）

- [x] 阶段 0：`nvidia-smi` / `CUDA available: True`（A800 80GB）
- [x] 阶段 1：代码 `/workspace/code/HAJIMI_UI` + `/workspace/code/OmniParser`
- [x] 阶段 2：OmniParser `:8002`，`/probe/` → `device=cuda`
- [x] 阶段 3：A FastAPI `:8010`，`DETECTOR_BACKEND=auto`，`server/.env` 已配置
- [x] 阶段 4：B 端 SSH 隧道访问 health 成功
- [x] 阶段 6：脚本联调 health OK（1×1 测试图 inspect/process SKIP 为正常）
- [ ] 阶段 6.4–6.5：**真实桌面截图** inspect / process（建议在 B 端 `python main.py` 人工验收）

### B 端（Windows）

- [x] 校园网 / VPN 可达 `10.246.2.7`
- [x] SSH 隧道或脚本建隧道
- [x] 浏览器 / 脚本 health OK
- [x] `%LOCALAPPDATA%/HAJIMI/user_settings.json` 已写「内网 API」
- [ ] **`python main.py` 真实桌面**「立即检测」+ 提问带红框（最终验收）

---

## 5. A → B 交接表（已填写 · 2026-07-01）

| 交接项 | 值 |
|--------|-----|
| 网络方案 | **B**（SSH 隧道；隧道断开则 B 不可达 A） |
| **A 端 Base URL** | `http://127.0.0.1:8010` |
| Demo Key | `hajimi-demo-2026` |
| health | `status=ok`，`detector_device=cuda`，`omniparser_ready=true` |
| 单次 inspect（GPU） | 约数秒～十几秒（真实桌面；非 1×1 测试图） |
| OmniParser 重启 | `bash /workspace/code/HAJIMI_UI/scripts/gpu_group2_container_services.sh start-omni` |
| A 端重启 | `bash /workspace/code/HAJIMI_UI/scripts/gpu_group2_container_services.sh start-a` |
| 日志目录 | `/workspace/code/HAJIMI_UI/logs/` |
| 已知限制 | 须保持 SSH 隧道；容器重建后可能需重新 `pip`/拉权重 |

**B 端联调步骤**：[`docs/校园GPU-B端联调清单_v2.md`](docs/校园GPU-B端联调清单_v2.md) §二。

---

## 6. 变更记录

| 日期 | 说明 |
|------|------|
| 2026-07-01 | 初版：group2 凭据；A/B 文档拆分；隧道方案 B；远程部署完成 |
